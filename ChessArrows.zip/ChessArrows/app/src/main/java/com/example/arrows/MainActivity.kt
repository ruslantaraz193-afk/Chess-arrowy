package com.example.arrows

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Разреши «Поверх других окон» и открой приложение снова", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val i = Intent(this, OverlayService::class.java)
        if (resultCode == RESULT_OK && data != null) {
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
        } else {
            Toast.makeText(this, "Без доступа к экрану авто-поиск доски не работает (доску можно обвести вручную)", Toast.LENGTH_LONG).show()
        }
        startForegroundService(i)
        finish()
    }
}
