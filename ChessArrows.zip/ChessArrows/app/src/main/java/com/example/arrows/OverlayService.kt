package com.example.arrows

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var canvas: ArrowView
    private lateinit var canvasLp: LP
    private lateinit var bar: LinearLayout
    private lateinit var barLp: LP
    private lateinit var btnDraw: TextView
    private lateinit var btnCal: TextView
    private lateinit var btnColor: TextView
    private lateinit var prefs: SharedPreferences

    private val ui = Handler(Looper.getMainLooper())
    private val work = HandlerThread("detect").also { it.start() }
    private val workH = Handler(work.looper)

    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var capW = 0
    private var capH = 0
    private val lock = Any()
    private var lastImage: Image? = null
    private var frameSeq = 0L
    private var busy = false
    private var started = false
    private var dying = false
    private var built = false

    private val palette = intArrayOf(
        0xFFFF8F00.toInt(), 0xFF43A047.toInt(), 0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFFFDD835.toInt()
    )
    private var colorIdx = 0

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_NOT_STICKY
        started = true
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra("data")

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("arrows", "Arrows", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "arrows")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Chess Arrows").build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, if (data != null) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            toast("Не удалось запустить сервис: " + e.message)
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
        if (data != null) {
            try {
                startCapture(code, data)
            } catch (e: Exception) {
                proj = null
                toast("Не удалось начать захват экрана: " + e.message)
            }
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- overlay UI

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun setActive(v: TextView, on: Boolean) {
        v.background = rounded(if (on) 0xFF3D7BFF.toInt() else 0x00000000, 12)
    }

    private fun btn(t: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = t
        textSize = 20f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = rounded(0x00000000, 12)
        setOnClickListener { onClick() }
    }

    private fun buildOverlay() {
        built = true
        prefs = getSharedPreferences("p", MODE_PRIVATE)
        colorIdx = prefs.getInt("ci", 0).coerceIn(0, palette.size - 1)

        canvas = ArrowView(this)
        canvas.color = palette[colorIdx]
        canvas.onBoardSet = { r ->
            saveBoard(r)
            setMode(1)
        }
        canvasLp = LP(
            LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        canvasLp.gravity = Gravity.TOP or Gravity.START
        // Android 12+ blocks touches through overlays with alpha > 0.8
        canvasLp.alpha = 0.8f
        if (Build.VERSION.SDK_INT >= 28) {
            canvasLp.layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        wm.addView(canvas, canvasLp)

        val handle = btn("≡") {}
        btnDraw = btn("✏") { onDrawTap() }
        val btnAuto = btn("◎") { autoDetect(null) }
        btnCal = btn("⌗") { setMode(if (canvas.mode == 2) 0 else 2) }
        btnColor = btn("●") {
            colorIdx = (colorIdx + 1) % palette.size
            canvas.color = palette[colorIdx]
            btnColor.setTextColor(palette[colorIdx])
            prefs.edit().putInt("ci", colorIdx).apply()
        }
        btnColor.setTextColor(palette[colorIdx])
        val btnUndo = btn("↶") { canvas.undo() }
        val btnClear = btn("✕") { canvas.clear() }
        val btnOff = btn("⏻") { stopSelf() }

        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xE6202124.toInt(), 18)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val all = listOf(handle, btnDraw, btnAuto, btnCal, btnColor, btnUndo, btnClear, btnOff)
        for (v in all) {
            val lp = LinearLayout.LayoutParams(dp(46), dp(46))
            lp.topMargin = dp(2)
            lp.bottomMargin = dp(2)
            bar.addView(v, lp)
        }

        barLp = LP(
            LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        )
        barLp.gravity = Gravity.TOP or Gravity.START
        barLp.x = dp(8)
        barLp.y = dp(120)

        var dx = 0f
        var dy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var collapsed = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; ox = barLp.x; oy = barLp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx
                    val my = e.rawY - dy
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) {
                        barLp.x = ox + mx.toInt()
                        barLp.y = oy + my.toInt()
                        wm.updateViewLayout(bar, barLp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        collapsed = !collapsed
                        for (v in all) if (v !== handle) v.visibility = if (collapsed) View.GONE else View.VISIBLE
                    }
                }
            }
            true
        }
        wm.addView(bar, barLp)
    }

    private fun setMode(m: Int) {
        canvas.mode = m
        canvasLp.flags = if (m == 0) canvasLp.flags or LP.FLAG_NOT_TOUCHABLE
        else canvasLp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(canvas, canvasLp)
        setActive(btnDraw, m == 1)
        setActive(btnCal, m == 2)
        canvas.invalidate()
        if (m == 2) toast("Обведи рамкой всю доску: из угла в угол")
    }

    private fun onDrawTap() {
        if (canvas.mode == 1) { setMode(0); return }
        canvas.board = loadBoard()
        if (canvas.board == null && proj != null) {
            autoDetect { ok -> if (ok) setMode(1) else setMode(2) }
        } else if (canvas.board == null) {
            setMode(2)
        } else {
            setMode(1)
        }
    }

    // ---------------------------------------------------------------- board storage (per orientation)

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun boardKey(): String {
        val (w, h) = realSize()
        return "b${w}x$h"
    }

    private fun saveBoard(r: RectF) {
        prefs.edit().putString(boardKey(), "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }

    private fun loadBoard(): RectF? {
        val s = prefs.getString(boardKey(), null) ?: return null
        val p = s.split(",")
        if (p.size != 4) return null
        return try {
            RectF(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat())
        } catch (e: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------- screen capture + board detection

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!dying) ui.post { stopSelf() }
            }
        }, ui)
        proj = p
        setupDisplay()
    }

    private fun capSize(): Pair<Int, Int> {
        val (rw, rh) = realSize()
        val sc = min(1f, 1440f / max(rw, rh))
        return Pair((rw * sc).toInt(), (rh * sc).toInt())
    }

    private fun setupDisplay() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val (w, h) = capSize()
        synchronized(lock) { lastImage?.close(); lastImage = null }
        val old = reader
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                synchronized(lock) {
                    lastImage?.close()
                    lastImage = img
                    frameSeq++
                }
            }
        }, workH)
        val d = vd
        if (d == null) {
            vd = proj!!.createVirtualDisplay(
                "arrows", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            d.resize(w, h, dm.densityDpi)
            d.surface = r.surface
        }
        reader = r
        try { old?.close() } catch (e: Exception) {}
        capW = w
        capH = h
    }

    private fun autoDetect(after: ((Boolean) -> Unit)?) {
        if (proj == null) {
            toast("Для авто-поиска нужен доступ к экрану: открой приложение заново и разреши запись экрана")
            after?.invoke(false)
            return
        }
        if (busy) return
        busy = true
        val (cw, ch) = capSize()
        if (cw != capW || ch != capH) {
            try { setupDisplay() } catch (e: Exception) {}
        }
        val before = synchronized(lock) { frameSeq }
        // hide our own overlay so it is not captured
        canvas.visibility = View.INVISIBLE
        bar.visibility = View.INVISIBLE
        ui.postDelayed({ waitFrame(before, 0, after) }, 300)
    }

    private fun waitFrame(before: Long, tries: Int, after: ((Boolean) -> Unit)?) {
        var pixels: IntArray? = null
        var w = 0
        var h = 0
        synchronized(lock) {
            val img = lastImage
            if (img != null && frameSeq > before) {
                try {
                    val pl = img.planes[0]
                    val rowPx = pl.rowStride / pl.pixelStride
                    val bmp = Bitmap.createBitmap(rowPx, img.height, Bitmap.Config.ARGB_8888)
                    pl.buffer.rewind()
                    bmp.copyPixelsFromBuffer(pl.buffer)
                    w = img.width
                    h = img.height
                    val arr = IntArray(w * h)
                    bmp.getPixels(arr, 0, w, 0, 0, w, h)
                    bmp.recycle()
                    pixels = arr
                } catch (e: Exception) {
                    pixels = null
                }
            }
        }
        if (pixels == null && tries < 8) {
            ui.postDelayed({ waitFrame(before, tries + 1, after) }, 200)
            return
        }
        canvas.visibility = View.VISIBLE
        bar.visibility = View.VISIBLE
        val px = pixels
        if (px == null) {
            busy = false
            toast("Не удалось снять экран. Обведи доску вручную (⌗)")
            after?.invoke(false)
            return
        }
        val ww = w
        val hh = h
        workH.post {
            val res = BoardDetector.detect(px, ww, hh)
            ui.post { onDetected(res, ww, hh, after) }
        }
    }

    private fun onDetected(res: BoardDetector.Result?, w: Int, h: Int, after: ((Boolean) -> Unit)?) {
        busy = false
        if (res == null) {
            toast("Доску не нашёл. Обведи её вручную (⌗)")
            after?.invoke(false)
            return
        }
        val (rw, rh) = realSize()
        val fx = rw.toFloat() / w
        val fy = rh.toFloat() / h
        val loc = IntArray(2)
        canvas.getLocationOnScreen(loc)
        val r = RectF(
            res.x * fx - loc[0], res.y * fy - loc[1],
            (res.x + res.size) * fx - loc[0], (res.y + res.size) * fy - loc[1]
        )
        canvas.board = r
        saveBoard(r)
        canvas.flashBoard()
        toast("Доска найдена")
        after?.invoke(true)
    }

    override fun onDestroy() {
        dying = true
        if (built) {
            try { wm.removeView(canvas) } catch (e: Exception) {}
            try { wm.removeView(bar) } catch (e: Exception) {}
        }
        synchronized(lock) { lastImage?.close(); lastImage = null }
        try { vd?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { proj?.stop() } catch (e: Exception) {}
        work.quitSafely()
        super.onDestroy()
    }
}
