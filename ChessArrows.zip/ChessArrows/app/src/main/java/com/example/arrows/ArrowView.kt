package com.example.arrows

import android.content.Context
import android.graphics.Canvas
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class ArrowView(c: Context) : View(c) {
    var mode = 0 // 0 = off (touches pass through), 1 = draw, 2 = manual board selection
    var board: RectF? = null
        set(v) { field = v; invalidate() }
    var color = 0xFFFF8F00.toInt()
    var onBoardSet: ((RectF) -> Unit)? = null

    private class A(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val col: Int)

    private val items = ArrayList<A>()
    private var cur: A? = null
    private var tmp: RectF? = null
    private var sx = 0f
    private var sy = 0f
    private var frameUntil = 0L

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x66000000 }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E676.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x8800E676.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f
    }

    fun clear() { items.clear(); cur = null; invalidate() }

    fun undo() {
        if (items.isNotEmpty()) items.removeAt(items.size - 1)
        invalidate()
    }

    /** Briefly shows the detected board and its 8x8 grid so the person can verify it. */
    fun flashBoard() {
        frameUntil = SystemClock.uptimeMillis() + 2000
        invalidate()
        postInvalidateDelayed(2050)
    }

    private fun sq(): Float = (board?.width() ?: 800f) / 8f

    // snap a point to the centre of its square (if the board is known)
    private fun snap(x: Float, y: Float): PointF {
        val b = board ?: return PointF(x, y)
        val w = b.width() / 8f
        val h = b.height() / 8f
        val cx = floor(((x - b.left) / w).coerceIn(0f, 7.99f))
        val cy = floor(((y - b.top) / h).coerceIn(0f, 7.99f))
        return PointF(b.left + (cx + 0.5f) * w, b.top + (cy + 0.5f) * h)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y
                if (mode == 1) { val p = snap(sx, sy); cur = A(p.x, p.y, p.x, p.y, color) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 1) {
                    val p = snap(e.x, e.y)
                    cur?.let { cur = A(it.x1, it.y1, p.x, p.y, it.col) }
                } else {
                    tmp = RectF(min(sx, e.x), min(sy, e.y), max(sx, e.x), max(sy, e.y))
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == 1) {
                    cur?.let { n ->
                        val dup = items.indexOfFirst {
                            abs(it.x1 - n.x1) < 1 && abs(it.y1 - n.y1) < 1 &&
                                abs(it.x2 - n.x2) < 1 && abs(it.y2 - n.y2) < 1
                        }
                        if (dup >= 0) items.removeAt(dup) else items.add(n)
                    }
                    cur = null
                } else {
                    tmp?.let { r ->
                        if (r.width() > 200 && r.height() > 200) { board = r; onBoardSet?.invoke(r) }
                    }
                    tmp = null
                }
            }
            MotionEvent.ACTION_CANCEL -> { cur = null; tmp = null }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        for (a in items) drawItem(c, a)
        cur?.let { drawItem(c, it) }
        if (mode == 2) {
            (tmp ?: board)?.let { drawGrid(c, it) }
        } else if (SystemClock.uptimeMillis() < frameUntil) {
            board?.let { drawGrid(c, it) }
        }
    }

    private fun drawGrid(c: Canvas, b: RectF) {
        c.drawRect(b, frame)
        for (i in 1..7) {
            val x = b.left + b.width() * i / 8f
            val y = b.top + b.height() * i / 8f
            c.drawLine(x, b.top, x, b.bottom, grid)
            c.drawLine(b.left, y, b.right, y, grid)
        }
    }

    private fun withAlpha(col: Int, a: Int): Int = (col and 0x00FFFFFF) or (a shl 24)

    private fun drawItem(c: Canvas, a: A) {
        val b = board
        val s = sq()
        val dist = hypot(a.x2 - a.x1, a.y2 - a.y1)

        // tap on a square = filled square highlight
        if (dist < s * 0.3f) {
            fill.pathEffect = null
            if (b != null) {
                val w = b.width() / 8f
                val h = b.height() / 8f
                fill.color = withAlpha(a.col, 0xB0)
                c.drawRect(a.x1 - w / 2, a.y1 - h / 2, a.x1 + w / 2, a.y1 + h / 2, fill)
            } else {
                rim.pathEffect = null
                rim.color = a.col
                rim.strokeWidth = s * 0.07f
                c.drawCircle(a.x1, a.y1, s * 0.46f, rim)
                rim.color = 0x66000000
            }
            return
        }

        val bw = s * 0.16f   // body width
        val hl = s * 0.48f   // head length
        val hw = s * 0.54f   // head width

        // route: straight, or L-shaped for knight moves
        val pts = ArrayList<PointF>()
        pts.add(PointF(a.x1, a.y1))
        if (b != null) {
            val w = b.width() / 8f
            val h = b.height() / 8f
            val dc = Math.round((a.x2 - a.x1) / w)
            val dr = Math.round((a.y2 - a.y1) / h)
            if (abs(dc) == 2 && abs(dr) == 1) pts.add(PointF(a.x2, a.y1))
            else if (abs(dc) == 1 && abs(dr) == 2) pts.add(PointF(a.x1, a.y2))
        }
        pts.add(PointF(a.x2, a.y2))

        // start slightly off the centre of the source square
        val f0 = pts[0]
        val f1 = pts[1]
        val d0 = hypot(f1.x - f0.x, f1.y - f0.y)
        pts[0] = PointF(f0.x + (f1.x - f0.x) / d0 * s * 0.1f, f0.y + (f1.y - f0.y) / d0 * s * 0.1f)

        val n = pts.size
        val t = pts[n - 1]
        val p = pts[n - 2]
        val dl = hypot(t.x - p.x, t.y - p.y)
        val ux = (t.x - p.x) / dl
        val uy = (t.y - p.y) / dl
        val bxp = t.x - ux * hl
        val byp = t.y - uy * hl

        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until n - 1) path.lineTo(pts[i].x, pts[i].y)
        path.lineTo(bxp, byp)
        body.strokeWidth = bw
        val outline = Path()
        body.getFillPath(path, outline)

        val head = Path()
        head.moveTo(t.x, t.y)
        head.lineTo(bxp - uy * hw / 2, byp + ux * hw / 2)
        head.lineTo(bxp + uy * hw / 2, byp - ux * hw / 2)
        head.close()
        if (!outline.op(head, Path.Op.UNION)) outline.addPath(head)

        val soft = CornerPathEffect(s * 0.04f)
        fill.pathEffect = soft
        fill.color = a.col
        c.drawPath(outline, fill)
        rim.pathEffect = soft
        rim.strokeWidth = max(1.5f, s * 0.012f)
        c.drawPath(outline, rim)
    }
}
