package com.example.arrows

import kotlin.math.abs
import kotlin.math.min

/** Finds an 8x8 checkerboard in a screenshot. Pure Kotlin: works on ARGB pixels. */
object BoardDetector {
    class Result(val x: Float, val y: Float, val size: Float)

    private val FX = floatArrayOf(0.15f, 0.85f, 0.15f, 0.85f)
    private val FY = floatArrayOf(0.15f, 0.15f, 0.85f, 0.85f)
    private val cols = IntArray(256)
    private val pars = IntArray(256)
    private val sum = DoubleArray(6)
    private val mean = DoubleArray(6)

    private fun pix(px: IntArray, w: Int, h: Int, x: Float, y: Float): Int {
        val xi = x.toInt().coerceIn(0, w - 1)
        val yi = y.toInt().coerceIn(0, h - 1)
        return px[yi * w + xi]
    }

    /** How well the 8x8 grid at (x0,y0,s) looks like alternating light/dark squares. */
    private fun fit(px: IntArray, w: Int, h: Int, x0: Int, y0: Int, s: Int): Double {
        val q = s / 8f
        var n = 0
        for (i in 0 until 6) sum[i] = 0.0
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val par = (r + c) and 1
                for (k in 0 until 4) {
                    val p = pix(px, w, h, x0 + (c + FX[k]) * q, y0 + (r + FY[k]) * q)
                    cols[n] = p
                    pars[n] = par
                    n++
                    val o = par * 3
                    sum[o] += ((p shr 16) and 255).toDouble()
                    sum[o + 1] += ((p shr 8) and 255).toDouble()
                    sum[o + 2] += (p and 255).toDouble()
                }
            }
        }
        for (i in 0 until 6) mean[i] = sum[i] / 128.0
        val dr = mean[0] - mean[3]
        val dg = mean[1] - mean[4]
        val db = mean[2] - mean[5]
        val contrast = dr * dr + dg * dg + db * db
        if (contrast < 300.0) return 0.0
        var acc = 0.0
        for (i in 0 until 256) {
            val p = cols[i]
            val o = pars[i] * 3
            val a = ((p shr 16) and 255) - mean[o]
            val b = ((p shr 8) and 255) - mean[o + 1]
            val c = (p and 255) - mean[o + 2]
            acc += min(a * a + b * b + c * c, contrast)
        }
        return contrast / (acc / 256.0 + 60.0)
    }

    private fun diff(a: Int, b: Int): Int =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) +
            abs(((a shr 8) and 255) - ((b shr 8) and 255)) +
            abs((a and 255) - (b and 255))

    /** Edge strength across the 14 inner grid lines: peaks when the grid is pixel-exact. */
    private fun edge(px: IntArray, w: Int, h: Int, x0: Float, y0: Float, s: Float): Double {
        val q = s / 8f
        var tot = 0L
        for (k in 1..7) {
            for (r in 0 until 8) {
                for (f in 0..1) {
                    val ff = if (f == 0) 0.12f else 0.88f
                    tot += diff(
                        pix(px, w, h, x0 + k * q - 1f, y0 + (r + ff) * q),
                        pix(px, w, h, x0 + k * q + 1f, y0 + (r + ff) * q)
                    )
                    tot += diff(
                        pix(px, w, h, x0 + (r + ff) * q, y0 + k * q - 1f),
                        pix(px, w, h, x0 + (r + ff) * q, y0 + k * q + 1f)
                    )
                }
            }
        }
        return tot / 224.0
    }

    fun detect(px: IntArray, w: Int, h: Int): Result? {
        val mn = min(w, h)
        var best = -1.0
        var bx = 0
        var by = 0
        var bs = 0

        // 1) coarse search over position and size
        var s = (mn * 0.35f).toInt()
        while (s <= mn) {
            var y = 0
            while (y + s <= h) {
                var x = 0
                while (x + s <= w) {
                    val sc = fit(px, w, h, x, y, s)
                    if (sc > best) { best = sc; bx = x; by = y; bs = s }
                    x += 8
                }
                y += 8
            }
            s += 8
        }
        if (best < 15.0) return null

        // 2) refine on grid-line edges
        val r = (0.2f * bs / 8f).toInt() + 8
        var eb = -1.0
        var rx = bx
        var ry = by
        var rs = bs
        var ds = -r
        while (ds <= r) {
            var dx = -r
            while (dx <= r) {
                var dy = -r
                while (dy <= r) {
                    val e = edge(px, w, h, (bx + dx).toFloat(), (by + dy).toFloat(), (bs + ds).toFloat())
                    if (e > eb) { eb = e; rx = bx + dx; ry = by + dy; rs = bs + ds }
                    dy += 2
                }
                dx += 2
            }
            ds += 2
        }

        // 3) pixel-level pass, centre of the best plateau
        val cands = ArrayList<DoubleArray>()
        var mx = -1.0
        for (ds2 in -3..3) {
            for (dx2 in -3..3) {
                for (dy2 in -3..3) {
                    val e = edge(px, w, h, (rx + dx2).toFloat(), (ry + dy2).toFloat(), (rs + ds2).toFloat())
                    cands.add(doubleArrayOf(e, (rx + dx2).toDouble(), (ry + dy2).toDouble(), (rs + ds2).toDouble()))
                    if (e > mx) mx = e
                }
            }
        }
        if (mx < 40.0) return null
        var sx = 0.0
        var sy = 0.0
        var ss = 0.0
        var cnt = 0
        for (c in cands) {
            if (c[0] >= 0.97 * mx) { sx += c[1]; sy += c[2]; ss += c[3]; cnt++ }
        }
        return Result((sx / cnt).toFloat(), (sy / cnt).toFloat(), (ss / cnt).toFloat())
    }
}
